//Define Librerias
#include "project.h"
#include "stdio.h"
#define BUFFER_LEN  64u //Tamaño del buffer

int main(void)
{
    //Variables para Manejar el Buffer
    uint16 Cuenta;
    uint8 buffer[BUFFER_LEN];
    char8 Texto[20];
    //Habilita las Interrupciones
    CyGlobalIntEnable;
    //Estos Tres parametros Van en grupo
    //Se encargar de que el computador detecte el USB-Serial
    USB_Start(0u, USB_3V_OPERATION);	
    while(!USB_GetConfiguration());
    USB_CDC_Init();
    /* Iniciar LCD */
    LCD_Start();
    LCD_Position(0,0);
    LCD_PrintString("Ejemplo USB");
    for(;;)
    {
        /* Coloquen aqui su aplicación */
        //Recibe Algo
        if(USB_DataIsReady() != 0u){               //Detecta si llego un dato nuevo
            Cuenta = USB_GetAll(buffer);           /*Lee cuantos datos se recibieron en el buffer*/
            sprintf(Texto,"%c Hecho",buffer[0]);   //Convierte la Información a String 
            USB_PutString(Texto);                  //Envia el String Mediante Serial
            //Escribe en la LCD lo que se envia
            LCD_Position(1,0);  
            LCD_PutChar(buffer[0]);
        }                
        //Envia Algo al Destino
        USB_PutString("Prueba");
        CyDelay(1000);
    }
}

/* [] END OF FILE */
