/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
uint8 Boton_1=0;
uint8 Boton_2=0;
uint16 Slider=0;

int main(void)
{
    CyGlobalIntEnable; 
    /* Iniciar Perifericos */
    LCD_Start();
    LCD_Position(0,0);
    LCD_PrintString("B1   B2   Slider");
    CapSense_Start();
    CapSense_InitializeAllBaselines();
    for(;;)
    {
        //Actuzalizar Estado del Sensor Capacitivo
        CapSense_UpdateEnabledBaselines();	
	    CapSense_ScanEnabledWidgets();
        while(CapSense_IsBusy() != 0){
              //Leer Estado de los botones
              Boton_1 = (uint8)CapSense_CheckIsWidgetActive(CapSense_B1__BTN);
              Boton_2 = (uint8)CapSense_CheckIsWidgetActive(CapSense_B2__BTN);
              //Leer estado del Slider
              Slider =(uint8)CapSense_GetCentroidPos(CapSense_LS__LS);
              LCD_Position(1,0);  
              LCD_PrintNumber(Boton_1);  
              LCD_Position(1,5);  
              LCD_PrintNumber(Boton_2);
              LCD_Position(1,10);  
              LCD_PrintNumber(Slider);  
              CyDelay(100);
            }
    }
}

/* [] END OF FILE */
